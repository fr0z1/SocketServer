﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SocketClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                IPHostEntry ipHost = Dns.GetHostEntry("localhost");
                IPAddress ipAddr = ipHost.AddressList[0];
                IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, 8080);

                Socket socket = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                socket.Connect(ipEndPoint);

                Connect(socket);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
            }
        }

        static void Connect(Socket socket)
        {
            Console.WriteLine("Чат");
            Console.Write("Введите имя: ");

            Thread SendTask = new Thread(() => Send(socket));
            Thread ReceiveTask = new Thread(() => Receive(socket));

            SendTask.Start();
            ReceiveTask.Start();
        }

        static void Send(Socket socket)
        {
            while (true)
            {
                byte[] msg = Encoding.UTF8.GetBytes(Console.ReadLine());
                int bytesSent = socket.Send(msg);
            }
        }

        static void Receive(Socket socket)
        {
            while (true)
            {
                string message;
                byte[] bytes = new byte[1024 * 4];

                int bytesRec = socket.Receive(bytes);
                message = Encoding.UTF8.GetString(bytes, 0, bytesRec);
                Console.WriteLine(message);
            }
        }

        static void Exit(Socket socket)
        {
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
        }
    }
}