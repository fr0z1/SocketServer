﻿using System;
using System.Text;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace SocketClient
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                IPHostEntry ipHost = Dns.GetHostEntry("localhost");
                IPAddress ipAddr = ipHost.AddressList[0];
                IPEndPoint ipEndPoint = new IPEndPoint(ipAddr, 8080);

                Socket socket = new Socket(ipAddr.AddressFamily, SocketType.Stream, ProtocolType.Tcp);

                socket.Connect(ipEndPoint);

                SendMessageFromSocket(socket);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            finally
            {
                Console.ReadLine();
            }
        }

        static void SendMessageFromSocket(Socket socket)
        {
            Console.WriteLine("Чат");

            Console.Write("Введите имя: ");
            string message = Console.ReadLine();
            Console.WriteLine("Подключение...");

            Thread SendTask = new Thread(() => Send(socket));
            Thread ReceiveTask = new Thread(() => Receive(socket));

            SendTask.Start();
            ReceiveTask.Start();

            Console.Clear();
            byte[] msg = Encoding.UTF8.GetBytes(message);
            int bytesSent = socket.Send(msg);
        }

        static void Send(Socket socket)
        {
            Thread SendTask = new Thread(() => Send(socket));
            string message = Console.ReadLine();

            if (message == "/exit") Exit(socket);

            byte[] msg = Encoding.UTF8.GetBytes(message);
            int bytesSent = socket.Send(msg);
            SendTask.Start();
        }

        static void Receive(Socket socket)
        {
            Thread ReceiveTask = new Thread(() => Receive(socket));
            string message;
            byte[] bytes = new byte[1024 * 4];

            int bytesRec = socket.Receive(bytes);
            message = Encoding.UTF8.GetString(bytes, 0, bytesRec);
            Console.WriteLine(message);
            ReceiveTask.Start();
        }

        static void Exit(Socket socket)
        {
            socket.Shutdown(SocketShutdown.Both);
            socket.Close();
        }
    }
}