﻿using System;
using System.Net.Sockets;

namespace SocketServer
{
    public class Client : IDisposable
    {
        public string endPoint;
        public string name;

        public Socket socket;

        public Client(Socket socket)
        {
            this.socket = socket;
            endPoint = socket.RemoteEndPoint.ToString();
        }

        public void Dispose()
        {
            socket.Dispose();
            GC.SuppressFinalize(this);
        }
    }
}
