﻿using System;
using System.Net.Sockets;

namespace SocketServer
{
    public class Client
    {
        public string endPoint;
        public string name;

        public Socket socket;

        public bool beConnected = false;
    
        public Client(Socket socket)
        {
            this.socket = socket;
            endPoint = socket.RemoteEndPoint.ToString();
        }
    }
}
